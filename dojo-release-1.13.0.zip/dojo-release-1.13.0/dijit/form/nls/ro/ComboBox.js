//>>built
define("dijit/form/nls/ro/ComboBox",({previousMessage:"Alegeri anterioare",nextMessage:"Mai multe alegeri"}));
