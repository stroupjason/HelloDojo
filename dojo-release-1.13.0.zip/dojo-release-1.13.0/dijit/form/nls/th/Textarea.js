//>>built
define("dijit/form/nls/th/Textarea",({iframeEditTitle:"พื้นที่แก้ไข",iframeFocusTitle:"กรอบพื้นที่แก้ไข"}));
