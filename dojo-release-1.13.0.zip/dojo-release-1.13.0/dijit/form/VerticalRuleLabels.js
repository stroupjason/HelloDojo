//>>built
define("dijit/form/VerticalRuleLabels",["dojo/_base/declare","./HorizontalRuleLabels"],function(_1,_2){
return _1("dijit.form.VerticalRuleLabels",_2,{templateString:"<div class=\"dijitRuleContainer dijitRuleContainerV dijitRuleLabelsContainer dijitRuleLabelsContainerV\"></div>",_positionPrefix:"<div class=\"dijitRuleLabelContainer dijitRuleLabelContainerV\" style=\"top:",_labelPrefix:"\"><span class=\"dijitRuleLabel dijitRuleLabelV\">",_calcPosition:function(_3){
return 100-_3;
},_isHorizontal:false});
});
